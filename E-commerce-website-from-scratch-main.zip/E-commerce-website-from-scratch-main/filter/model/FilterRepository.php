<?php
    namespace App\filter\model;

    interface FilterRepository{
        public function getCategory();
    }
?>