$(document).ready(function(){
    $('.collapse').collapse('hide');
    
    $("#errorModal").modal('show');
});