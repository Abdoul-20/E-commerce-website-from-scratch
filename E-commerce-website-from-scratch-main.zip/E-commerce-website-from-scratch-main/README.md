# E-commerce-website-from-scratch
An e-commerce website built from scratch with HTML, CSS, JavaScript and PHP based on MVC pattern.
